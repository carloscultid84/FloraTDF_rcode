####Rcode to fitting and selection of the models on relationship between qD ~ environmental variables. Environmental variables: dm = Minimal distances (m) between sampling localities and the external boundary of the urban core; pal = percent of anthropic landcovers; elev = sampling site elevation####

####Packages####

library(performance)
library(lattice)
library(performance)
library(lme4)
library(tidyverse)
library(caret)
library(MASS)
library(ggplot2)
library(qqplotr)
library(PerformanceAnalytics)
library(lm.br)
library(corrplot)
library(Hmisc)
library(EnvStats)
library(datawizard)
library(dplyr)
library(tidyr)
library(stringr)
library(see)
library(DHARMa)
library(gridExtra)
library(MuMIn)
library(ggrepel)

####Input data###

qdvx <- read.csv("qD_VX.csv", header = T) ######Table with diversity estimations and predictors variables
qd <- qdvx[,c(3:5)] ###extract diversity estimations
vx <- qdvx[,c(6,8,9)] ###extract predictors variables
svx <- scale(vx) #### scaling predictors variables to models fitting
dsvx <- data.frame(svx) 

####models selections with Mumin packages to species richness 0D####

m0 <- glm(qd$X0D ~., dsvx, family = poisson(link = "log"))
summary(m2)
plot(check_collinearity(m0))

options(na.action = "na.fail")

m.mod0 <- dredge(m0, rank = "AICc")
m.e0 <- subset(m.mod0, delta < 2)
mmg_0 <- get.models(m.e0, subset=TRUE)

summary(mmg_0$`5`)
shapiro.test(residuals(mmg_0$`5`))

sim_res5 <- simulateResiduals(mmg_0$`5`) ####the fith model was the potential minial model specification.

testOverdispersion(sim_res5)
plot(sim_res5)

####manual exploratio of the model selected####

D0 <- qd$X0D
olc <- dsvx$olc
rd <- data.frame(cbind(olc, D0)) ####starting table 

msel <- glm(D0 ~ olc, family = poisson(link = "log")) ###This is the model "5"
summary(msel) ### the null hypothesis on olc coefficient was rejected.   
anova(msel)

##r2 estimations

(r2_mcfadden <- r2_mcfadden(glm(D0 ~ olc + 1, family = poisson(link = "log"))))
(r2_correlation <- cor(msel$model$D0, msel$fitted.values)^2)

####Code to plotting the predictions model selected to species richness####

solc <- scale(vx$olc)
sd_s_olc <- attr(solc, "scaled:scale")

means <- mean(vx$olc) ######media observada
sds <- sd(vx$olc)  ######sd observada

resumen <- summary(msel)
coef_scaled <- coef(msel)
ee_escalados <- resumen$coefficients[, "Std. Error"]

# Coeficientes originales (solo predictores escalados)
coef_original <- coef_scaled[-1] / sds  # Excluir intercepto

# Intercepto original
intercept_original <- coef_scaled[1] - sum(coef_scaled[-1] * (means / sds))

expbo <- exp(intercept_original) ###This coefficient will using to make the predictions plot in observed units of the both variables (response and predictors).

predicciones <- predict(msel, interval = "confidence", level = 0.95)

rd$pred <- predicciones[, "fit"]
rd$lwr <- predicciones[, "lwr"]  # Lower limit
rd$upr <- predicciones[, "upr"]  # Upper limit

intercepto <- expbo
pendiente <- coef_scaled[2]

polc <- vx$olc ###predictor in real units
rd$polc <- polc 

rd$pred_manual <- intercepto + pendiente * rd$polc

t0d <- readRDS("tplot_0D.rds") ####This table was obteined from 01_Rcode_Jimenez_et_al

##This allow us insert the 95% CI of the qD per point.  

rd$Li <- t0d$Li
rd$range <- t0d$range
rd$Site <- t0d$Localidad

fig0 <- ggplot(rd, aes(x = polc, y = D0)) +
  geom_ribbon(aes(ymin = exp(lwr), ymax = exp(upr)), fill = "gray70", alpha = 0.3) +
  geom_errorbar(aes(ymin=D0-range, ymax=D0+range), width =.1, colour="gray30")+
  geom_point(color = "black", size = 3, alpha = 0.7) +
  geom_line(aes(y = pred_manual), color = "gray60", linewidth = 1.0)+
  #geom_text_repel(aes(label = Site))+
  labs(title = "",
       x = "Percent of the anthropic landcovers",
         y = "Species richness of flora") +
  theme_bw(base_family = "Times", base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5, face = "italic"),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1)
  )

ggsave("Figure_0D_IC95.jpg", plot = fig0, width = 15, height = 15, units = "cm", dpi = 200, quality = 95)

#####models selections with Mumin packages to dominant species richness 1D####

m1 <- glm(qd$X1D ~., dsvx, family = poisson(link = "log"))
summary(m1)
plot(check_collinearity(m1))

options(na.action = "na.fail")

m.mod1 <- dredge(m1, rank = "AICc")
m.e1 <- subset(m.mod1, delta < 2)
mmg_1 <- get.models(m.e1, subset=TRUE)

####conclusion 1: The linear fitting is no informative. After graphical explore an exponential model was evaluated:

D1 <- qd$X1D
olc <- dsvx$olc
olc2 <- (dsvx$olc)^2

rd$olc2 <- olc2
rd$D1 <- D1

msel <- glm(D1 ~ olc + I((olc)^2), family = poisson(link = "log"))
summary(msel)
anova(msel)

shapiro.test(residuals.glm(msel))
(r2_mcfadden <- r2_mcfadden(msel))
(r2_correlation <- cor(msel$model$D1, msel$fitted.values)^2)

####conclusion 2: The exponential specification was informative and The diagnosis of the model indicated that it complies with the assumptions about the residuals.

##################Ensayo para gráfico correcto##################################

solc <- scale(vx$olc)

meadia_s_olc <- attr(solc, "scaled:center")
sd_s_olc <- attr(solc, "scaled:scale") ##SD de la variable escalada

# Crear secuencia en escala estandarizada
#olc_scaled_seq <- seq(min(rd$olc), max(rd$olc), length.out = 100)
olc_scaled_seq <- seq(min(rd$olc), max(rd$olc), length.out = 100)

# Hacer predicciones
pre_test <- predict(msel, 
                        newdata = data.frame(olc = olc_scaled_seq),
                        type = "response")

# Predicciones con SE
pred_se <- predict(msel, 
                   newdata = data.frame(olc = olc_scaled_seq),
                   type = "response",
                   se.fit = TRUE)

# Des-escalar para el plot
olc_real_seq <- olc_scaled_seq * sd_s_olc + meadia_s_olc

df_pred <- data.frame(olc_real = olc_real_seq, 
                      D1_pred = pre_test)

df_pred_ic <- data.frame(
  olc_real = olc_real_seq,
  fit = exp(pred_se$fit),
  lower = exp(pred_se$fit - 1.96 * pred_se$se.fit),
  upper = exp(pred_se$fit + 1.96 * pred_se$se.fit)
)

#También des-escalar tus datos originales para el plot

rd$olc_real <- rd$olc * sd_s_olc + meadia_s_olc
rd$D2 <- qd$X2D  
#saveRDS(rd, "rd.rds")

t1d <- readRDS("tplot_1D.rds") ####This table was obteined from 01_Rcode_Jimenez_et_al
rd$range_1d <- t1d$range 

fig1 <-  ggplot() +
  geom_ribbon(data = df_pred_ic, mapping = aes(x = olc_real, ymin = lower, ymax = upper),
              fill = "gray70", alpha = 0.3) +
  geom_errorbar(rd, mapping = aes(x = olc_real, ymin=D1-range_1d, ymax=D1+range_1d), width =.1, colour="gray30")+
  geom_line(data = df_pred_ic, mapping = aes(x = olc_real, y = fit), 
            color = "gray40", linewidth = 1)+
  #geom_text_repel(rd, mapping = aes(olc_real, D1, label = Site))+
  geom_point(rd, mapping = aes(olc_real, D1), color = "black", size = 3, alpha = 0.7) + 
  labs(title = "",
       x = "Percent of the anthropic landcovers",
       y = "Effective number of species") +
  theme_bw(base_family = "Times", base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5, face = "italic"),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1)
  )

ggsave("Figure_1D_IC95.jpg", plot = fig1, width = 15, height = 15, units = "cm", dpi = 200, quality = 95)

######Figure to 2D and RLE 01D and 02D####

####Data####

rd <- readRDS("rd.rds")
t2d <- readRDS("tplot_2D.rds")
rd$range_2d <- t2d$range 

RLE1D <- readRDS("RLE1D.rds")

RLE1Do <-  RLE1D %>% 
  mutate(Loc = factor(Loc, levels = c("bonito_gordo", "Buenos_Aires", "Kalashe_Kalabia_", "Llorona", "Palangana", "Parcela", "PN_Tayrona")))  %>%
  arrange(Loc)

RLE2D <- readRDS("RLE2D.rds")
RLE2Do <-  RLE2D %>% 
  mutate(Loc = factor(Loc, levels = c("bonito_gordo", "Buenos_Aires", "Kalashe_Kalabia_", "Llorona", "Palangana", "Parcela", "PN_Tayrona")))  %>%
  arrange(Loc)

rd$rle1 <- RLE1Do$Value
rd$rle2 <- RLE2Do$Value

fig2 <- ggplot(rd, aes(x = polc, y = D2)) +
  #geom_ribbon(aes(ymin = exp(lwr), ymax = exp(upr)), fill = "gray70", alpha = 0.3) +
  geom_errorbar(aes(ymin=D2-range, ymax=D2+range), width =.1, colour="gray30")+
  geom_point(color = "black", size = 3, alpha = 0.7) +
  geom_smooth(method = "lm",  color = "gray60", se = FALSE, linetype = "dashed") +
  #geom_line(aes(y = pred_manual), color = "gray60", linewidth = 1.0)+
  #geom_text_repel(aes(label = Site))+
  labs(title = "",
       x = "Percent of the anthropic landcovers",
       y = "Species richness of flora") +
  theme_bw(base_family = "Times", base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5, face = "italic"),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1)
  )

ggsave("Figure_2D_IC95.jpg", plot = fig2, width = 15, height = 15, units = "cm", dpi = 200, quality = 95)

####RLE####

rle01 <- ggplot(rd, aes(x = polc, y = rle1)) +
  #geom_ribbon(aes(ymin = exp(lwr), ymax = exp(upr)), fill = "gray70", alpha = 0.3) +
  #geom_errorbar(aes(ymin=D2-range, ymax=D2+range), width =.1, colour="gray30")+
  geom_point(color = "black", size = 3, alpha = 0.7) +
  #geom_line(aes(y = pred_manual), color = "gray60", linewidth = 1.0)+
  #geom_text_repel(aes(label = Site))+
  labs(title = "",
       x = "Percent of the anthropic landcovers",
       y = "Hill's evenness (1D/0D)") +
  theme_bw(base_family = "Times", base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5, face = "italic"),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1)
  )

ggsave("Figure_2D_IC95.jpg", plot = fig2, width = 15, height = 15, units = "cm", dpi = 200, quality = 95)

rle02 <- ggplot(rd, aes(x = polc, y = rle2)) +
  #geom_ribbon(aes(ymin = exp(lwr), ymax = exp(upr)), fill = "gray70", alpha = 0.3) +
  #geom_errorbar(aes(ymin=D2-range, ymax=D2+range), width =.1, colour="gray30")+
  geom_point(color = "black", size = 3, alpha = 0.7) +
  #geom_line(aes(y = pred_manual), color = "gray60", linewidth = 1.0)+
  #geom_text_repel(aes(label = Site))+
  labs(title = "",
       x = "Percent of the anthropic landcovers",
       y = "Hill's evenness (2D/0D)") +
  theme_bw(base_family = "Times", base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5, face = "italic"),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1)
  )

####Merge plot to RLE 1 y 2####


# Reestructurar el dataframe
rd_long <- rd %>%
  pivot_longer(cols = c(rle1, rle2), 
               names_to = "variable", 
               values_to = "valor")

# Crear el gráfico
# Crear el gráfico
rlep <- ggplot(rd_long, mapping = aes(x = polc, y = valor, color = variable, fill = variable, shape = variable)) +
  geom_point(size = 3, color = "black", alpha = 0.7) +
  geom_smooth(method = "lm",  se = FALSE, linetype = "dashed") +
  scale_color_manual(values = c("rle1" = "gray60", "rle2" = "gray30"),
                     labels = c("Variable 1", "Variable 2")) +
  scale_fill_manual(values = c("rle1" = "gray60", "rle2" = "gray30"),
                    labels = c("Variable 1", "Variable 2")) +
  scale_shape_manual(values = c("rle1" = 16, "rle2" = 17)) +
  scale_y_continuous(limits = c(0, 1))+
  #geom_text_repel(aes(label = Site))+
  labs(title = "",
       x = "Percent of the anthropic landcovers",
       y = "Hill's evennes") +
  theme_bw(base_family = "Times", base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5, face = "italic"),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1)
  )

ggsave("Figure_RLEs.jpg", plot = rlep, width = 15, height = 15, units = "cm", dpi = 200, quality = 95)