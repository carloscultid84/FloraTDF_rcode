####Rcode to diversity estimations with Hill´series####

####Packages#### 

install.packages("iNEXT")

library(iNEXT)
library(ggplot2)
library(ggpubr)
library(reshape2)

####Input data###

spp1 <- readRDS("tv.rds")
t_spp1 <- t(spp1)

di <- DataInfo(t_spp1)
ep <- max(di$n)

####Diversity estimations####

out<-iNEXT(t_spp1, q=c(0, 1, 2), datatype="abundance", endpoint=ep, knots = 120, nboot = 1000)

write.table(out$iNextEst$size_based, "out_caribe_2.txt")

####Plot of the qD diversity regarding to out_caribe_2.txt using observed estimations#### 

tplot <- read.csv("tplot.csv", header = T)
tplot$range <- tplot$Value - tplot$Li  

###Localities acceding sort according to the Minimal distances (m) between sampling localities and the external boundary of the urban core

tplot$Localidad <- factor(tplot$Localidad, levels = c("Parcela", "bonito_gordo", "Llorona", "Palangana", "Buenos_Aires", "Kalashe_Kalabia_", "PN_Tayrona")) 

pd <- position_dodge(0.1) 

windows()

tp <- ggplot(tplot, aes(x = Localidad, y = Value, group = factor(qD),  shape = factor(qD)))+
  geom_errorbar(aes(ymin=Value-range, ymax=Value+range), width =.1, colour="black")+
  geom_point(size = 2)+
  geom_line(lty = 2, size = 0.2)+
  theme_classic()+
  xlab("Locality")+
  ylab("Number of the effective species")+
  theme(text=element_text(size=14, family = "TT Times New Roman"))+
  theme(panel.background=element_rect(fill="transparent",color='black', linewidth=1))

q0 <- expression(" "^0*"D")
q1 <- expression(" "^1*"D")
q2 <- expression(" "^2*"D")

#tiff("fig2ge.tiff", units="in", width=5, height=5, res=100)
f2B <- tp + theme(legend.position.inside = c(0.15, 0.88))+
  theme(legend.title = element_blank())+
  scale_shape_discrete(label = c(q0, q1, q2))+
  theme(legend.text = element_text(colour = "black", size = 12, family = "TT Times New Roman"))+
  guides(shape = guide_legend(override.aes = list(size = 4)))
#dev.off()

ggsave("fig_qD_spp_corr.jpeg", width = 25, height = 17, units = "cm", dpi = 200)

###Evenness plot from Hill' series####

eh1 <- tplot[,c(1:3)]
head(eh1)

eh <-  acast(eh1, Localidad~qD, value.var="Value")
head(eh)
class(eh)
ehd <- data.frame(eh)

ehd$RLE01 <- log(ehd$X1)/log(ehd$X0)
ehd$RLE02 <- log(ehd$X2)/log(ehd$X0)

ehd$RE01 <- ehd$X1/ehd$X0
ehd$RE02 <- ehd$X2/ehd$X0

windows()
plot(ehd$RLE01, ehd$RE01)


Loc <- rep(rownames(ehd),2)
eh <- c(rep("RLE01",7), rep("RLE02",7)) 
Value <- c(ehd$RLE01, ehd$RLE02)

eht <- data.frame(Loc, eh, Value) #### Table os the Hill's evenness de Hill (Jost 2010).

eht$RE <- exp(eht$Value)

###Localities acceding sort according to the Minimal distances (m) between sampling localities and the external boundary of the urban core

eht$Loc <- factor(eht$Loc, levels = c("Parcela", "bonito_gordo", "Llorona", "Palangana", "Buenos_Aires", "Kalashe_Kalabia_", "PN_Tayrona")) 

pd <- position_dodge(0.1) 

windows()

ggplot(eht, aes(x = Loc, y = Value, group = factor(eh),  shape = factor(eh)))+
  geom_point(size = 2)+
  geom_line(lty = 2, linewidth = 0.2)+
  theme_classic()+
  ylim(0, 1.0)+
  xlab("Locality")+
  ylab("Eveness")+
  theme(text=element_text(size=14, family = "TT Times New Roman"))+
  theme(panel.background=element_rect(fill="transparent",color='black', linewidth=1))

ggsave("fig_RLE_corr.jpeg", width = 25, height = 17, units = "cm", dpi = 200)