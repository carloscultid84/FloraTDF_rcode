####Rcode to beta diversity####

####Packages####

library(ggplot2)
library(pvclust)
library(fpc)
library(BAT)
library(fpc)
library(vegan)
library(ggdendro)
library(grid)
library(viridis)
library(RColorBrewer)
require(dplyr)
require(forcats)
library(pvclust)
library(reshape2)

####inpunt data####

b.tv <- readRDS("b.tv_s112.rds")

####Betapair####

betaJ <- beta(b.tv, abund = F, func = "jaccard", runs = 1000)

bcc.j <- betaJ$Btotal; bcc.m <- as.matrix(bcc.j) 
rownames(bcc.m) <- rownames(b.tv) 
colnames(bcc.m) <- rownames(b.tv)
bccJ <- as.dist(bcc.m)

brep.j <- betaJ$Brepl; brep.m <- as.matrix(brep.j)
rownames(brep.m) <- rownames(b.tv) 
colnames(brep.m) <- rownames(b.tv)
brepJ <- as.dist(brep.m)

brich.j <- betaJ$Brich; brich.m <- as.matrix(brich.j)
rownames(brich.m) <- rownames(b.tv) 
colnames(brich.m) <- rownames(b.tv)
brichJ <- as.dist(brich.m)

####Beta total####

betaTs <- beta.multi(b.tv, abund = FALSE, func = "jaccard", runs = 1000)
bT <- data.frame(betaTs)

####Bar plot of the beta. Figure 3####

Beta.m <- c("Btotal", "Brec", "Brich")
value <- c(bT$Average[-c(4,5)])
var <- c(bT$Variance[-c(4,5)])
sd <- sqrt(var)

t.beta <- data.frame(Beta.m, value, sd)

sum(value)
round((0.5701760*100)/0.7874472,2) ##Beta turnover contribution at beta total
round((0.2172712*100)/0.7874472,2) ##Beta richness contribution at beta total

ggplot(t.beta, aes(x=reorder(Beta.m, -value), y=value)) + 
  geom_bar(stat="identity", color="black", 
           position=position_dodge()) +
  geom_errorbar(aes(ymin=value-sd, ymax=value+sd), width=.1,
                position=position_dodge(.9))+
  xlab("Componente de Beta")+
  ylab("Beta promedio")+
  theme_classic()+
  ylim(0.0,1.0)+
  scale_fill_grey()+
  #theme(axis.title.x=element_blank(),
  #axis.text.x=element_blank(),
  #axis.ticks.x=element_blank())+
  theme(text=element_text(size=8, family = "TT Times New Roman"))+
  theme(panel.background=element_rect(fill="transparent",color='black',size=1))+
  theme(legend.position = c(0.85, 0.90))+
  theme(legend.title = element_blank())

ggsave("fig_betaverages_08_2022.jpeg", width = 12.5, height = 16.2, units = "cm", dpi = 150)

####Clusters to beta diversity###########
####beta total

d1T <- bccJ
pfit1.T <- hclust(d1T, method="average")  
plot(pfit1.T, hang = -1)

otter.dendro.bt <- as.dendrogram(hclust(d1T, method="average")) ##This will use to heatmap sorting

dendro.plot <- ggdendrogram(otter.dendro.bt, rotate = T)
print(dendro.plot)

####beta turnover

d2T <- brepJ
pfit2T <- hclust(d2T, method="average")
plot(pfit2T, hang = -1)

otter.dendro.rep <- as.dendrogram(hclust(d2T, method="average"))
dendro.plot <- ggdendrogram(otter.dendro.rep, rotate = T)
print(dendro.plot)

####beta richness
d3T <- brichJ
pfit3T <- hclust(d3T, method="average")  
plot(pfit3T, hang = -1)

otter.dendro.rich <- as.dendrogram(hclust(d3T, method="average"))
dendro.plot <- ggdendrogram(otter.dendro.rich, rotate = T)
print(dendro.plot)

####boostratping to each beta####

kbest.p1T <- 2
bclus1T <- clusterboot(d1T, B = 1000, distances = T, clustermethod = disthclustCBI, method ="average", k=kbest.p1T)

kbest.p2T <- 2
bclus2T <- clusterboot(d2T, B = 1000, distances = T, clustermethod = disthclustCBI, method ="average", k=kbest.p2T)

kbest.p3T <- 2
bclus3T <- clusterboot(d3T, B = 1000, distances = T, clustermethod = disthclustCBI, method ="average", k=kbest.p3T)

####components groups verification

groups1T<-bclus1T$result$partition  

groups2T<-bclus2T$result$partition  

groups3T<-bclus3T$result$partition  

####Heatmap plot figure 4####

### data ###

m <- readRDS("mm.rds")
mheat <- as.matrix(m)
t.mheat <- t(mheat)

th <- melt(mheat)
head(th)
colnames(th) <- c("Sitio", "sp_planta", "CB")

heat <- th


heat <- heat %>%
  mutate(sp_planta = gsub("_", " ", sp_planta))

head(heat)

heat$sp_planta <- factor(heat$sp_planta)
levels(heat$sp_planta)

#####Re-order hetamap rows to match dendrogram########
####

otter_order <- order.dendrogram(otter.dendro.bt)

# Order the levels according to their position in the cluster
heat$Sitio <- factor(x = heat$Sitio,
                     levels = heat$Sitio[otter_order], 
                     ordered = TRUE)

cols <- brewer.pal(9, "Blues")

pal <- colorRampPalette(cols)

head(heat)
heat$lCB <- log(heat$CB+1) 


# Re-ordering regarding otter_order
ggplot(heat, aes(reorder(sp_planta, -lCB), y = Sitio)) +     
  geom_tile(aes(fill = lCB), colour = "black", na.rm = TRUE, size = 0.1) +
  scale_fill_gradientn(name = "ln(N)", colours = pal(20)) + 
  theme_classic()+
  #geom_hline(yintercept = 10.5, size = 1, color = "grey")+
  #theme_bw() +
  ggtitle("") + 
  xlab("spp plantas") + 
  ylab("Sitios") + 
  theme(plot.title = element_text(family = "Sans", face = "bold", size = 20, hjust=0.5), legend.text = element_text(family = "Sans", size = 8), axis.text.y = element_text(family = "Sans", face = "bold", size =5), axis.text.x = element_text(family = "Sans", face = "italic", size =5, angle = 90), axis.title = element_text(family = "Sans", face = "bold", size = 14), legend.title = element_text(family = "Sans", face = "bold", size = 10), legend.position = "bottom") + 
  theme(panel.background=element_rect(fill='transparent',color='black',linewidth=1))

ggsave("heatmap_plantas_012025.png", dpi = 300, width = 18, height = 18, units = "cm")

